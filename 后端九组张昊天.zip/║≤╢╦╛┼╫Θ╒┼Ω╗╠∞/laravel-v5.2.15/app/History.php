<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class History extends Model {

    protected $table = 'history';

    public $timestamps = false;
}