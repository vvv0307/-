<?php

namespace App\Http\Controllers;




use Illuminate\Http\Request;

class testController extends Controller{
    public function test(Request $request){
        $id = $request->input('id');
        echo $id;
    }
}