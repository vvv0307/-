<?php

namespace App\Http\Controllers;

use App\Article;
use App\History;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ArticleController extends Controller{
    //增加新闻 request请求
    public function AddArticle(Request $request){
        //获取相关参数
        $title = $request->input('title');
        $content = $request->input('content');
        $field = $request->input('field');
        //获取当前时间
        $time = date('Y-m-d H-i-s', time() + 8 * 60 * 60);
        //article
        $article = new Article();
        //查询
        $field_id = DB::select('select id FROM field WHERE field = ?', [$field]);
        $id = $field_id[0]->id;
        $article->title = $title;
        $article->content = $content;
        $article->field_id = $id;
        $article->publish_time = $time;
        $bool = $article->save();
        //判断是否保存
        if ($bool) {
            return response()->json(['errorCode' => 0, 'data' => $bool, 'msg' => '成功！']); //返回response响应 json
        } else {
            //$arr['msg'] = '失败！';
            return response()->json(['msg' => '失败']);
        }
    }
    //根据id更新新闻，使用ruquest请求传递参数
    public function UpdateArticle(Request $request,$id){
        $title = $request->input('title');            //获取title
        $content = $request->input('content');        //获取content
        $field = $request->input('field');            //获取field
        $time = date('Y-m-d H-i-s',time()+8*60*60);     //获取当前时间戳
        $num = DB::update('UPDATE article a LEFT JOIN field f ON a.id = ?
        SET a.title = ?,a.content = ?,a.publish_time = ? ,a.field_id = f.id WHERE f.field = ?',
            [$id,$title,$content,$time,$field]);              //联合更新

        /*笨办法 $article = Article::find($id);
        $field_id = DB::select('select id FROM field WHERE field = ?',[$field]);
        $fid = $field_id[0]->id;
        $article -> title = $title;
        $article -> content = $content;
        $article -> field_id = $fid;
        $article -> publish_time = $time;
        $bool = $article ->save();*/
        if($num){
            return response()->json(['errorCode'=>0,'data'=>$num,'msg'=>'成功！']);   //返回response响应json
        }else {
            return response()->json(['msg'=>'失败！']);
        }
    }
    //根据id删除新闻
    public function DeleteArticle($id){
        $article = Article::find($id);
        $bool = $article -> delete();
        if($bool){
            return response()->json(['errorCode'=>0,'data'=>$bool,'msg'=>'成功！']);
        }else{
            return response()->json(['data'=>$bool,'msg'=>'失败！']);
        }
    }
    //查询相关领域新闻，或者查询全部新闻
    public function SelectArticleBy($field=null){                       //field设置一个默认值
        if($field){                                                     //判断field，如果传了参数按参数查询，否则默认为null
            /*笨办法：$field_id = DB::select('select id FROM field WHERE field = ?',[$field]);
            $fid = $field_id[0]->id;
            $article = Article::where('field_id','=',$fid) -> get(['title','content','publish_time']);*/
            //使用join
            $article = DB::select('select a.title,a.content,a.publish_time FROM article a
             INNER JOIN field f WHERE a.field_id = f.id AND f.field = ?',[$field]);
            if($article){
                return response()->json(['errorCode'=>0,'data'=>$article,'msg'=>'成功！']);
            }else{
                return response()->json(['data'=>$article,'msg'=>'失败！']);
            }
        }else{
            $article = Article::get(['title','content','publish_time']);
            if($article){
                return response()->json(['errorCode'=>0,'data'=>$article,'msg'=>'成功！']);
            }else{
                return response()->json(['data'=>$article,'msg'=>'失败！']);
            }
        }
    }
    //根据id查询
    public function SelectArticle($id){
        $article = Article::where('id','=',$id) -> get (['title','content','publish_time']);
        $date = date('Y-m-d');
        $time = date('Y-m-d H-i-s',time()+8*60*60);
        $title = $article[0] -> title;
        $content = $article[0] -> content;
        $publish_time = $article[0] -> publish_time;
        $history = new History();
        $history -> title = $title;
        $history -> content = $content;
        $history -> publish_time = $publish_time;
        $history -> read_date = $date;
        $history -> read_time = $time;
        $bool = $history -> save();
        if($bool && $article){
            return response()->json(['errorCode'=>0,'data'=>$article,'msg'=>'成功！']);
        }else{
            return response()->json(['data'=>$article,'msg'=>'成功！']);
        }
    }

}
