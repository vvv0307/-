<?php

namespace App\Http\Controllers;

use App\History;
use App\Http\Requests\Request;
use function MongoDB\BSON\toJSON;

class HistoryController extends Controller{
    //按日期显示历史，每个日期中历史记录按浏览时间倒序
    //这里有一个参数$page 需要前端获取，初始值为0，每次点击加载page+10，退出浏览历史page重置为0
    public function getHistory($page){
        //查询数据库history表，按浏览时间倒序，分页查询从$page条开始，每次5条记录，10条也行，但是不好测试，还要存值十条以上
        //获取其中的title和read_date字段
        $history = History::orderBy('read_time','desc')-> offset($page) ->limit(5) -> get(['title','read_date']);
        //循环结果把read_date赋值给一个数组
        for($i = 0;$i<sizeof($history);$i++){
             $a[$i] = $history[$i] -> read_date;
        }
        //去掉重复的read_date值
        $uniqueArr = array_unique($a);
        //得到的数组键可能不连续或者不从零开始，使用array_values函数，得到从零开始的连续键
        $sequentialArr = array_values($uniqueArr);

        //return $sequentialArr;
        //得到$sequentialArr的数组长度
        $num = sizeof($sequentialArr);
        //return $uniqueArr
        //echo $num;
        //定义一个新数组b
        $b = array();
        //把sequentialArr分配给b的两个数组元素
        for($i = 0;$i<$num;$i++){
            $b[$sequentialArr[$i]] = array();
        }
        //return $sequentialArr;
        //return $b;
        //双循环，判断如果history中的read_date和$sequentialArr相同，把相应的title添加进相应的b中数组元素
        for($i = 0;$i<$num;$i++){
            for($n = 0;$n<sizeof($history);$n++) {
                if ($sequentialArr[$i] == $history[$n]->read_date) {
                    $title = $history[$n]->title;
                    array_push($b[$sequentialArr[$i]],$title);
                }
            }
        }
        //return $sequentialArr;
        //查询的历史条数，小于5说明历史记录已经全部查询出来
        if(sizeof($history)<5){
            return response()->json(['errorCode'=>0,'data'=>$b,'msg'=>'成功，已经到底了']);
        }else {
            return response()->json(['errorCode'=>0,'data'=>$b,'msg'=>'成功']);
        }
    }
    //获取全部历史记录，时间倒序输出
    public function getAllHistory(){
        $history = History::orderBy('read_time','desc') -> get(['title']);
        //$arr['errorCode'] = 0;
        //$arr['data'] = $history;
        //$arr['msg'] = '成功';
        return response()->json(['errorCode'=>0,'data'=>$history,'msg'=>'成功']);
    }
}