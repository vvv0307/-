<?php

use App\Http\Controllers\ArticleController;
/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('article/add','ArticleController@AddArticle');

Route::post('article/update/{id}','ArticleController@UpdateArticle');

Route::delete('article/delete/{id}','ArticleController@DeleteArticle');

Route::get('article/get/{field?}','ArticleController@SelectArticleBy');

Route::get('article/detail/{id}','ArticleController@SelectArticle');

Route::get('history/get/{page}','HistoryController@getHistory');

Route::get('history/getall','HistoryController@getAllHistory');

Route::any('request','testController@test');

/*Route::get('test',function(){
    echo date('Y-m-d H:i:s',time()+8*60*60);
});*/
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware' => ['web']], function () {
    //
});
